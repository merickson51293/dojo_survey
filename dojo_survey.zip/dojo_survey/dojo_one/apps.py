from django.apps import AppConfig


class DojoOneConfig(AppConfig):
    name = 'dojo_one'
