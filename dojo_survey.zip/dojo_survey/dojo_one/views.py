from django.shortcuts import render, redirect

def survey(request):
    if request.method == "GET":
    	print("a GET request is being made to this route")
    	return render(request, "survey.html")
    if request.method == "POST":
        print("a POST request is being made to this route")
        return redirect(request, "result.html")

def result(request):
    if request.method == "GET":
    	print("a GET request is being made to this route")
    	return render(request, "survey.html")
    if request.method == "POST":
        print(request.POST)
        context = {
            "val_from_name":request.POST['name'],
            "val_from_location":request.POST['location'],
            "val_from_lang":request.POST['lang'],
            "val_from_comment":request.POST['comment']
        }
        return render(request, "result.html", context)